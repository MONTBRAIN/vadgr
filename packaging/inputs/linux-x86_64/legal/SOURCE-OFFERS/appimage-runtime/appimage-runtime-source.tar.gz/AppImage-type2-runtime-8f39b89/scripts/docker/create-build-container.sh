#! /bin/bash

set -euo pipefail

orig_cwd="$(readlink -f .)"

if [[ "${ARCH:-}" == "" ]]; then
    echo "Usage: env ARCH=[...] $0"
    exit 2
fi

# guess architecture name compatible with Docker from $ARCH
case "${ARCH}" in
    x86_64)
        docker_platform=linux/amd64
        ;;
    i686)
        docker_platform=linux/i386
        ;;
    armhf)
        docker_platform=linux/arm/v6
        ;;
    aarch64)
        docker_platform=linux/arm64/v8
        ;;
    *)
        echo "Unsupported architecture: $ARCH"
        exit 3
        ;;
esac

image_name=type2-runtime-build

# first, we need to build the image
# if nothing has changed, it'll run over this within a few seconds
repo_root_dir="$(readlink -f "$(dirname "${BASH_SOURCE[0]}")")"/../../
docker build --platform "$docker_platform" -t "$image_name" -f "$repo_root_dir"/scripts/docker/Dockerfile "$repo_root_dir"

docker_run_args=()
[[ -t 0 ]] && docker_run_args+=("-t")

# split Docker args from command
while true; do
    # no more args left
    if [[ "${1:-}" == "" ]]; then
        break
    fi

    # consume --, the remaining args will be in the $@ array
    if [[ "$1" == "--" ]]; then
        shift
        break
    fi

    # append and consume Docker arg
    docker_run_args+=("$1")
    shift
done

# finally, we can run the build container
# we run the build as an unprivileged user to a) make sure that the build process does not require root permissions and b) make the resulting binary writable to the current user
exec docker run -u "$(id -u):$(id -g)" --platform "$docker_platform" --rm -i "${docker_run_args[@]}" -w /ws -v "$repo_root_dir":/ws -v "$orig_cwd":/ws/out "$image_name" "$@"
