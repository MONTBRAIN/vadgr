"""Offline source recipe. Receipt identity is build configuration, not authority."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

def require(value, message):
    if not value:
        raise ValueError(message)

def identity(path):
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= 16 * 1024 * 1024,
            'receipt must be a bounded regular file')
    raw = path.read_bytes()
    data = json.loads(raw)
    require(raw == (json.dumps(data, indent=2, sort_keys=True) + '\n').encode(), 'noncanonical receipt')
    require(data.get('schema') == 1 and data.get('development') is True and data.get('publishable') is False
            and data.get('signing') == 'disabled' and data.get('attestation') == 'absent'
            and data.get('platform') == 'linux' and data.get('architecture') == 'x86_64',
            'not an unsigned Linux x86_64 development receipt')
    require(all(isinstance(data.get(n), str) and re.fullmatch('[a-f0-9]{40}', data[n])
                for n in ('source_commit', 'source_tree')), 'invalid compile identity')
    require(isinstance(data.get('artifact'), dict) and isinstance(data.get('appdir'), list),
            'final AppImage development receipt required')
    return {k: data[k] for k in ('source_commit', 'source_tree')}, hashlib.sha256(raw).hexdigest()

def verify_application(root):
    rows = json.loads((root / 'application-files.json').read_bytes())
    expected = {r['path']: r for r in rows}
    require(len(expected) == len(rows), 'duplicate application manifest member')
    actual = {}
    for p in (root / 'application').rglob('*'):
        relative = p.relative_to(root / 'application').as_posix()
        # Recipe owns this output directory; Cargo source config is separately supplied.
        if relative == 'target' or relative.startswith('target/'):
            continue
        require(not p.is_symlink(), 'linked application source')
        if p.is_file():
            if relative == '.cargo/config.toml':
                recorded = dict(line.split('  ', 1)[::-1] for line in (root / 'SHA256SUMS').read_text().splitlines())
                require(recorded.get('application/' + relative) == hashlib.sha256(p.read_bytes()).hexdigest(),
                        'supplied Cargo source configuration changed')
                continue
            actual[relative] = {'path': relative, 'mode': p.stat().st_mode & 0o777,
                                'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
        else:
            require(p.is_dir(), 'special application source')
    require(actual == expected, 'application source differs from snapshot manifest')
    import types
    module_path = root / 'application/scripts/rust_path_patches.py'
    module = types.ModuleType('delivered_path_patches')
    exec(compile(module_path.read_bytes(), '<delivered-path-patches>', 'exec'), module.__dict__)
    require(len(module.load(root / 'application')) == 2, 'delivered patch source binding differs')

def build_command(root, receipt, check_only=False):
    ids, receipt_hash = identity(receipt)
    verify_application(root)
    app = (root / 'application').resolve()
    environment = dict(os.environ)
    environment.pop('CARGO_ENCODED_RUSTFLAGS', None)
    environment.update(RUSTUP_TOOLCHAIN='1.97.1', CARGO_BUILD_JOBS='2',
        VADGR_RELEASE_PROFILE='linux-x86_64', VADGR_RELEASE_PAYLOAD_BUILD='1',
        VADGR_QUALIFICATION_SOURCE_COMMIT=ids['source_commit'],
        VADGR_QUALIFICATION_SOURCE_TREE=ids['source_tree'], SOURCE_DATE_EPOCH='1609459200',
        CARGO_TARGET_DIR=str(app / 'target'), RUSTFLAGS=f'--remap-path-prefix={app}=/vadgr-source')
    command = ['cargo', 'build', '--offline', '--locked', '--release', '--features',
               'linux-unsigned-qualification', '--target', 'x86_64-unknown-linux-gnu', '--bin', 'vadgr']
    print(json.dumps({'compile_identity': ids, 'supplied_receipt_sha256': receipt_hash,
                      'source_only_recipe': True, 'final_package_correspondence_claimed': False,
                      'command': command, 'cargo_invoked': not check_only}, sort_keys=True))
    if not check_only:
        subprocess.run(command, cwd=app, env=environment, check=True)
    return command, environment

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--receipt', type=Path, required=True)
    p.add_argument('--check-only', action='store_true')
    args = p.parse_args()
    build_command(Path(__file__).resolve().parent, args.receipt, args.check_only)

if __name__ == '__main__':
    main()
