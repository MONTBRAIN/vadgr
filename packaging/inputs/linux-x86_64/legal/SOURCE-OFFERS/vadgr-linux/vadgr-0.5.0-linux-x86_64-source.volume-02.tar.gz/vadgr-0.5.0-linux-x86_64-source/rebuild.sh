#!/bin/sh
set -eu
exec python3 "$(dirname -- "$0")/receipt_rebuild.py" "$@"
