use super::ToolServer;
use crate::cua_payload::CuaCommand;
use crate::engine::types::{ImageSource, McpError, ToolContent, ToolResult, ToolSpec};
use async_trait::async_trait;
use rmcp::model::{CallToolRequestParams, ContentBlock};
use rmcp::service::RunningService;
use rmcp::transport::{ConfigureCommandExt, TokioChildProcess};
use rmcp::{RoleClient, ServiceExt};
use serde_json::{Map, Value};
use std::ffi::OsString;
use std::process::Stdio;
use std::time::Duration;
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::task::JoinHandle;

const STDERR_LINE_LIMIT: usize = 4096;
const CLOSE_TIMEOUT: Duration = Duration::from_secs(3);

pub struct CuaServer {
    command: CuaCommand,
    environment: Vec<(OsString, OsString)>,
    /// Whether the installed runtime was re-verified for the next spawn.
    revalidated: bool,
    client: Option<RunningService<RoleClient, ()>>,
    stderr_task: Option<JoinHandle<()>>,
}

impl CuaServer {
    pub fn new(command: CuaCommand) -> Self {
        Self {
            command,
            environment: Vec::new(),
            revalidated: false,
            client: None,
            stderr_task: None,
        }
    }

    pub(crate) fn with_environment(
        command: CuaCommand,
        environment: Vec<(OsString, OsString)>,
    ) -> Self {
        Self {
            command,
            environment,
            revalidated: false,
            client: None,
            stderr_task: None,
        }
    }

    /// Re-verify the installed runtime on a blocking thread. It reads the whole
    /// installed package, which held an async worker for tens of seconds.
    async fn revalidate(&mut self) -> Result<(), McpError> {
        let command = self.command.clone();
        tokio::task::spawn_blocking(move || command.revalidate())
            .await
            .map_err(|error| McpError::Server(error.to_string()))?
            .map_err(|error| McpError::Server(error.to_string()))?;
        self.revalidated = true;
        Ok(())
    }

    async fn connect(&mut self) -> Result<(), McpError> {
        if self.client.is_some() {
            return Ok(());
        }
        if !self.revalidated {
            self.revalidate().await?;
        }
        // Every spawn is preceded by its own check.
        self.revalidated = false;
        let child = self.command.clone();
        let environment = self.environment.clone();
        let mut command = tokio::process::Command::new(&child.program).configure(|command| {
            command
                .args(&child.args)
                .envs(environment)
                .kill_on_drop(true);
            configure_windows_process(command);
        });
        let authorization = child
            .prepare_process(command.as_std_mut())
            .map_err(|error| McpError::Server(error.to_string()))?;
        let (transport, stderr) = TokioChildProcess::builder(command)
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|error| McpError::Server(error.to_string()))?;
        drop(authorization);
        let stderr =
            stderr.ok_or_else(|| McpError::Server("cua stderr was not piped".to_owned()))?;
        self.stderr_task = Some(tokio::spawn(async move {
            let mut lines = BufReader::new(stderr).lines();
            while let Ok(Some(line)) = lines.next_line().await {
                let line: String = line.chars().take(STDERR_LINE_LIMIT).collect();
                tracing::debug!(server = "computer-use", stderr = line);
            }
        }));
        match ().serve(transport).await {
            Ok(client) => {
                self.client = Some(client);
                Ok(())
            }
            Err(error) => {
                self.finish_stderr().await;
                Err(McpError::Server(error.to_string()))
            }
        }
    }

    async fn finish_stderr(&mut self) {
        if let Some(mut task) = self.stderr_task.take()
            && tokio::time::timeout(CLOSE_TIMEOUT, &mut task)
                .await
                .is_err()
        {
            task.abort();
            let _ = task.await;
        }
    }
}

#[async_trait]
impl ToolServer for CuaServer {
    fn namespace(&self) -> &str {
        "computer-use"
    }

    async fn prepare(&mut self) -> Result<(), McpError> {
        if self.client.is_some() {
            return Ok(());
        }
        self.revalidate().await
    }

    async fn list_tools(&mut self) -> Result<Vec<ToolSpec>, McpError> {
        self.connect().await?;
        let tools = self
            .client
            .as_ref()
            .expect("connected client")
            .list_all_tools()
            .await
            .map_err(|error| McpError::Server(error.to_string()))?;
        Ok(tools
            .into_iter()
            .map(|tool| ToolSpec {
                name: tool.name.into_owned(),
                description: tool
                    .description
                    .map(|value| value.into_owned())
                    .unwrap_or_default(),
                input_schema: (*tool.input_schema).clone(),
            })
            .collect())
    }

    async fn call_tool(
        &mut self,
        name: &str,
        args: Map<String, Value>,
    ) -> Result<ToolResult, McpError> {
        let client = self
            .client
            .as_ref()
            .ok_or_else(|| McpError::Server("cua is not connected".to_owned()))?;
        let result = client
            .call_tool(CallToolRequestParams::new(name.to_owned()).with_arguments(args))
            .await
            .map_err(|error| McpError::Server(error.to_string()))?;
        let mut content = Vec::with_capacity(result.content.len());
        for block in result.content {
            content.push(match block {
                ContentBlock::Text(text) => ToolContent::Text { text: text.text },
                ContentBlock::Image(image) => ToolContent::Image {
                    source: ImageSource {
                        kind: "base64".to_owned(),
                        media_type: image.mime_type,
                        data: image.data,
                    },
                },
                other => {
                    return Err(McpError::UnsupportedContent(format!("{other:?}")));
                }
            });
        }
        Ok(ToolResult {
            content,
            is_error: result.is_error.unwrap_or(false),
        })
    }

    async fn close(&mut self) {
        if let Some(mut client) = self.client.take() {
            match client.close_with_timeout(CLOSE_TIMEOUT).await {
                Ok(Some(_)) => {}
                Ok(None) => tracing::warn!(server = "computer-use", "cua close timed out"),
                Err(error) => tracing::warn!(server = "computer-use", %error, "cua close failed"),
            }
        }
        self.finish_stderr().await;
    }
}

#[cfg(windows)]
fn configure_windows_process(command: &mut tokio::process::Command) {
    const CREATE_NO_WINDOW: u32 = 0x08000000;
    command.creation_flags(CREATE_NO_WINDOW);
}

#[cfg(not(windows))]
fn configure_windows_process(_command: &mut tokio::process::Command) {}
