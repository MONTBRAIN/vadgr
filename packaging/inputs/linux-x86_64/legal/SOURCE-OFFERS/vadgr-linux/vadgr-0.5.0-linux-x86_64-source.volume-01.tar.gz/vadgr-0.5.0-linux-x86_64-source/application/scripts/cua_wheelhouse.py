#!/usr/bin/env python3
"""Materialize the reviewed target closure for an offline source build.

Never resolves dependencies or approves a new hash. PyPI catalog entries must
match the reviewed selected digest; custom outputs use exact artifact IDs.
"""

from __future__ import annotations

import argparse
import email
import io
import itertools
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import unicodedata
import zipfile

if __package__:
    from scripts import cua_release_inputs as release
    from scripts.validate_package_inputs import (
        PackageInputError, canonical_json, parse_json, read_owned, relative_path,
        require, sha256_bytes,
    )
else:
    import cua_release_inputs as release
    from validate_package_inputs import (
        PackageInputError, canonical_json, parse_json, read_owned, relative_path,
        require, sha256_bytes,
    )

MAX_ARCHIVE = 256 * 1024 * 1024
MAX_EXPANDED = 1024 * 1024 * 1024


def binary_architecture(data):
    if len(data) >= 64 and data[:2] == b"MZ":
        offset = struct.unpack_from("<I", data, 0x3c)[0]
        require(offset <= len(data) - 6 and data[offset:offset + 4] == b"PE\0\0", "invalid PE header")
        machine = struct.unpack_from("<H", data, offset + 4)[0]
        require(machine in (0x8664, 0xaa64), "unsupported PE architecture")
        return "pe", {0x8664: "x86_64", 0xaa64: "aarch64"}[machine]
    if len(data) >= 64 and data[:6] == b"\x7fELF\x02\x01":
        machine = struct.unpack_from("<H", data, 18)[0]
        require(machine in (62, 183), "unsupported ELF architecture")
        return "elf", {62: "x86_64", 183: "aarch64"}[machine]
    if len(data) >= 32 and data[:4] == b"\xcf\xfa\xed\xfe":
        machine = struct.unpack_from("<I", data, 4)[0]
        require(machine in (0x1000007, 0x100000c), "unsupported Mach-O architecture")
        return "macho", {0x1000007: "x86_64", 0x100000c: "aarch64"}[machine]
    if len(data) >= 8 and data[:4] in (b"\xca\xfe\xba\xbe", b"\xca\xfe\xba\xbf"):
        count = struct.unpack_from(">I", data, 4)[0]
        width = 20 if data[3] == 0xbe else 32
        require(count in (1, 2) and len(data) >= 8 + count * width, "invalid universal Mach-O header")
        architectures = []
        for index in range(count):
            cpu = struct.unpack_from(">I", data, 8 + index * width)[0]
            require(cpu in (0x1000007, 0x100000c), "unsupported universal Mach-O architecture")
            architectures.append({0x1000007: "x86_64", 0x100000c: "aarch64"}[cpu])
        require(len(set(architectures)) == count, "duplicate universal Mach-O architecture")
        return "macho", "+".join(sorted(architectures))
    raise PackageInputError("missing or unsupported native executable header")


def normalized(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def compatible(tag: str, target: str) -> bool:
    release.lock_path(target)
    fields = tag.split("-")
    if len(fields) != 3:
        return False
    python, abi, platform = fields
    abi_ok = ((python in ("py3", "py312", "cp312") and abi == "none")
              or (python == "cp312" and abi == "cp312")
              or (re.fullmatch(r"cp3[0-9]+", python) is not None
                  and 2 <= int(python[3:]) <= 12 and abi == "abi3"))
    if not abi_ok:
        return False
    if platform == "any":
        return abi == "none"
    architecture = target.split("-", 1)[0]
    if target.endswith("pc-windows-msvc"):
        return platform == {"aarch64": "win_arm64", "x86_64": "win_amd64"}[architecture]
    if target.endswith("apple-darwin"):
        match = re.fullmatch(r"macosx_([0-9]+)_([0-9]+)_(x86_64|arm64|universal2)", platform)
        return bool(match and (int(match[1]), int(match[2])) <= (13, 0)
                    and match[3] in ({"arm64", "universal2"} if architecture == "aarch64"
                                     else {"x86_64", "universal2"}))
    match = re.fullmatch(r"manylinux_2_([0-9]+)_(x86_64|aarch64)", platform)
    if match:
        # The shared Linux/WSL closure may not exceed WSL's glibc 2.35 floor.
        return int(match[1]) <= 35 and match[2] == architecture
    return platform in {f"manylinux2014_{architecture}"} | (
        {"manylinux1_x86_64", "manylinux2010_x86_64"} if architecture == "x86_64" else set())


def filename_tags(filename: str) -> tuple[str, str, set[str]]:
    require(relative_path(filename) == filename and "/" not in filename and filename.endswith(".whl"),
            "unsafe wheel filename")
    parts = filename[:-4].split("-")
    require(len(parts) in (5, 6), "invalid wheel filename")
    require(len(parts) == 5 or re.fullmatch(r"[0-9][A-Za-z0-9_]*", parts[2]),
            "invalid wheel build tag")
    package, version = parts[:2]
    require(re.fullmatch(r"[A-Za-z0-9_.]+", package) and re.fullmatch(r"[A-Za-z0-9_.!+]+", version),
            "invalid wheel package identity")
    tags = {"-".join(row) for row in itertools.product(*(part.split(".") for part in parts[-3:]))}
    return normalized(package), version, tags


def archive_members(data: bytes, *, limit=MAX_ARCHIVE) -> dict[str, bytes]:
    require(len(data) <= limit, "wheel archive exceeds size limit")
    members, seen, total = {}, set(), 0
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        require(len(archive.infolist()) <= 20_000, "wheel archive has too many members")
        for item in archive.infolist():
            name = item.filename.rstrip("/")
            relative_path(name)
            key = unicodedata.normalize("NFC", name).casefold()
            require(key not in seen, "wheel archive has duplicate or case-colliding members")
            seen.add(key)
            kind = (item.external_attr >> 16) & 0o170000
            require(not item.flag_bits & 1 and kind in (0, 0o100000, 0o040000)
                    and not item.external_attr & 0x400, "wheel archive contains link or special member")
            if item.is_dir():
                continue
            require(kind in (0, 0o100000), "wheel archive file has directory type")
            total += item.file_size
            require(total <= MAX_EXPANDED, "wheel archive expands beyond limit")
            contents = archive.read(item)
            require(len(contents) == item.file_size, "wheel archive member size differs")
            members[name] = contents
    file_keys = {unicodedata.normalize("NFC", path).casefold() for path in members}
    for name in seen:
        require(not any("/".join(name.split("/")[:index]) in file_keys
                        for index in range(1, len(name.split("/")))), "wheel archive file/directory collision")
    return members


def validate_wheel(data, filename, name, version, target, *, profile=None, role_manifest=None):
    package, wheel_version, tags = filename_tags(filename)
    require(package == name and wheel_version == version and any(compatible(tag, target) for tag in tags),
            "wheel target, ABI or package differs")
    members = archive_members(data)
    metadata_names = [key for key in members if key.endswith(".dist-info/METADATA")]
    require(len(metadata_names) == 1, "wheel has ambiguous package metadata")
    metadata_name = metadata_names[0]
    metadata_parts = metadata_name.removesuffix(".dist-info/METADATA").rsplit("-", 1)
    require("/" not in metadata_parts[0] and len(metadata_parts) == 2
            and normalized(metadata_parts[0]) == name and metadata_parts[1] == version,
            "wheel metadata directory differs from selected package")
    wheel_name = metadata_name.removesuffix("METADATA") + "WHEEL"
    require(wheel_name in members, "wheel tag metadata absent")
    metadata = email.message_from_bytes(members[metadata_name])
    wheel = email.message_from_bytes(members[wheel_name])
    require(metadata.get_all("Name") is not None and len(metadata.get_all("Name")) == 1
            and normalized(metadata["Name"]) == name and metadata.get_all("Version") == [version]
            and set(wheel.get_all("Tag", [])) == tags and len(wheel.get_all("Tag", [])) == len(tags),
            "wheel metadata does not match selected identity")
    if profile is not None and name == "vadgr-computer-use":
        if __package__:
            from scripts import cua_profiles
        else:
            import cua_profiles
        require(cua_profiles.target_for(profile) == target, "profile differs from Rust target")
        cua_profiles.validate_members(members, profile, role_manifest)
        return members
    expected = target.split("-", 1)[0]
    kind = "pe" if target.endswith("windows-msvc") else "macho" if target.endswith("apple-darwin") else "elf"
    for content in members.values():
        if content[:2] == b"MZ" or content[:4] in (b"\x7fELF", b"\xcf\xfa\xed\xfe", b"\xca\xfe\xba\xbe", b"\xca\xfe\xba\xbf"):
            native_kind, architecture = binary_architecture(content)
            require(native_kind == kind and expected in architecture.split("+"),
                    "wheel includes incompatible native executable")
    return members


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        return None


def fetch(url: str, limit: int) -> bytes:
    address = urllib.parse.urlsplit(url)
    require(address.scheme == "https" and address.hostname in {"pypi.org", "files.pythonhosted.org"}
            and not address.username and not address.password and not address.query and not address.fragment
            and address.port in (None, 443), "wheel download origin refused")
    with urllib.request.build_opener(NoRedirect).open(url, timeout=90) as response:
        data = response.read(limit + 1)
    require(len(data) <= limit, "wheel response exceeds limit")
    return data


def upstream_wheel(name, version, digest, target):
    catalog = parse_json(fetch(f"https://pypi.org/pypi/{urllib.parse.quote(name, safe='')}/"
                               f"{urllib.parse.quote(version, safe='')}/json", release.MAX_METADATA))
    selected = [row for row in catalog.get("urls", []) if row.get("packagetype") == "bdist_wheel"
                and row.get("digests", {}).get("sha256") == digest and row.get("yanked") is False]
    require(len(selected) == 1, "reviewed upstream wheel is unavailable or ambiguous")
    row = selected[0]
    require(any(compatible(tag, target) for tag in filename_tags(row["filename"])[2]),
            "reviewed upstream wheel is incompatible")
    data = fetch(row["url"], MAX_ARCHIVE)
    require(type(row.get("size")) is int and len(data) == row["size"] and sha256_bytes(data) == digest,
            "upstream wheel bytes differ from reviewed lock")
    return row["filename"], data


def custom_wheel(row):
    result = subprocess.run(["gh", "api", "--method", "GET",
                             f"repos/{release.REPOSITORY}/actions/artifacts/{row['artifact_id']}/zip"],
                            cwd=Path(__file__).resolve().parents[1],
                            capture_output=True, timeout=120, check=False)
    require(result.returncode == 0 and len(result.stdout) <= MAX_ARCHIVE
            and "sha256:" + sha256_bytes(result.stdout) == row["artifact_digest"],
            "reviewed native wheel artifact cannot be retrieved")
    members = archive_members(result.stdout)
    require(set(members) == {row["filename"], "build-report.json", "tests.xml", "build-sbom.json"},
            "native wheel artifact set differs")
    for member, field in (("build-report.json", "build_report_sha256"), ("tests.xml", "test_report_sha256"),
                          ("build-sbom.json", "build_sbom_sha256"), (row["filename"], "sha256")):
        require(sha256_bytes(members[member]) == row[field], "native wheel artifact member changed")
    require(len(members[row["filename"]]) == row["size"], "native wheel size changed")
    return row["filename"], members[row["filename"]]


def profile_inputs(source, trusted, target, profile):
    promoted = any((root / "packaging/cua/profile-inputs.json").exists() for root in (source, trusted))
    if profile is None and not promoted:
        return release.reviewed_inputs(source, trusted, target), release.lock_path(target), None
    if __package__:
        from scripts import cua_profiles
    else:
        import cua_profiles
    profile = profile or cua_profiles.native_profile(target)
    binding, inputs, catalog = cua_profiles.reviewed(source, trusted, profile)
    require(binding["target"] == target, "profile differs from build target")
    return binding, cua_profiles.lock_path(profile), (inputs, catalog)


def materialize(source: Path, trusted: Path, target: str, output: Path, profile=None):
    require(output.is_absolute() and not output.exists() and output.parent.is_dir() and not output.is_symlink(),
            "wheelhouse output must be a new directory")
    require(all(not path.is_symlink() and not getattr(path, "is_junction", lambda: False)()
                for path in (output.parent, *output.parent.parents)), "wheelhouse output parent is linked")
    binding, lock_name, profiles = profile_inputs(source, trusted, target, profile)
    profile = binding.get("release_profile")
    release.verify_origin(trusted)
    _, manifest = release.manifest(trusted)
    selected = release.selected_lock(read_owned(source if profiles is not None else trusted, lock_name))
    profile_files = None
    if profiles is not None:
        if __package__:
            from scripts import cua_profiles
        else:
            import cua_profiles
        profile_files = cua_profiles.retrieve(trusted, *profiles, source=source)
    with tempfile.TemporaryDirectory(prefix="vadgr-wheelhouse-", dir=output.parent) as temporary:
        stage = Path(temporary) / "closed"
        stage.mkdir()
        records = []
        for name, (version, digest) in sorted(selected.items()):
            custom = [row for row in manifest["wheels"] if row["sha256"] == digest]
            if profile_files is not None and name == "vadgr-computer-use":
                entry = profiles[1]["profiles"][profile]
                filename = entry["wheel"]["filename"]
                data = profile_files[filename]
            elif custom:
                require(len(custom) == 1 and name == "cryptography" and version == "50.0.1"
                        and custom[0]["target"] == release.CUSTOM_TARGETS.get(target),
                        "custom wheel is not reviewed for this target")
                filename, data = custom_wheel(custom[0])
            else:
                filename, data = upstream_wheel(name, version, digest, target)
            require(sha256_bytes(data) == digest, "wheel differs from selected target lock")
            validate_wheel(data, filename, name, version, target, profile=profile,
                           role_manifest=binding.get("cua_profile_manifest_sha256"))
            with (stage / filename).open("xb") as stream:
                stream.write(data)
            records.append({"filename": filename, "name": name, "version": version,
                            "size": len(data), "sha256": digest})
        (stage / "wheelhouse.json").write_bytes(canonical_json({"schema": 1, **binding, "wheels": records}))
        require(not output.exists(), "wheelhouse output appeared during materialization")
        stage.rename(output)


def verify_materialized(source: Path, trusted: Path, target: str, output: Path, profile=None):
    """Recheck the closed bytes offline before executing any feature code."""
    require(output.is_absolute() and output.is_dir()
            and all(not path.is_symlink() and not getattr(path, "is_junction", lambda: False)()
                    for path in (output, *output.parents)), "wheelhouse directory is linked or missing")
    binding, lock_name, _ = profile_inputs(source, trusted, target, profile)
    profile = binding.get("release_profile")
    selected = release.selected_lock(read_owned(source if profile is not None else trusted, lock_name))
    metadata = parse_json(read_owned(output, "wheelhouse.json"))
    require(set(metadata) == {"schema", *binding, "wheels"}
            and type(metadata["schema"]) is int and metadata["schema"] == 1
            and all(metadata[key] == value for key, value in binding.items())
            and isinstance(metadata["wheels"], list), "offline wheelhouse binding differs")
    expected, observed = {"wheelhouse.json"}, set()
    for row in metadata["wheels"]:
        require(isinstance(row, dict)
                and set(row) == {"filename", "name", "version", "size", "sha256"}
                and isinstance(row["name"], str) and row["name"] not in observed
                and selected.get(row["name"]) == (row["version"], row["sha256"])
                and type(row["size"]) is int and 0 < row["size"] <= MAX_ARCHIVE,
                "offline wheel record differs")
        name = relative_path(row["filename"])
        require("/" not in name and name not in expected, "offline wheel filename differs")
        data = read_owned(output, name)
        require(len(data) == row["size"] and sha256_bytes(data) == row["sha256"],
                "offline wheel bytes differ")
        validate_wheel(data, name, row["name"], row["version"], target, profile=profile,
                       role_manifest=binding.get("cua_profile_manifest_sha256"))
        expected.add(name)
        observed.add(row["name"])
    require(observed == set(selected) and {path.name for path in output.iterdir()} == expected,
            "offline wheelhouse file set differs")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--target", choices=sorted(release.TARGETS), required=True)
    parser.add_argument("--release-profile", help="Reviewed build profile; not a runtime override")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--out", type=Path)
    mode.add_argument("--verify", type=Path)
    args = parser.parse_args()
    try:
        operation = verify_materialized if args.verify else materialize
        operation(args.source.resolve(), Path(__file__).resolve().parents[1], args.target,
                  (args.verify or args.out).absolute(), args.release_profile)
    except (PackageInputError, OSError, ValueError, TypeError, KeyError, zipfile.BadZipFile,
            subprocess.SubprocessError):
        print("CUA wheelhouse refused: reviewed closure or producer verification failed.", file=sys.stderr)
        return 1
    print("Reviewed CUA wheelhouse verified offline." if args.verify
          else "Reviewed CUA wheelhouse materialized for offline assembly.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
