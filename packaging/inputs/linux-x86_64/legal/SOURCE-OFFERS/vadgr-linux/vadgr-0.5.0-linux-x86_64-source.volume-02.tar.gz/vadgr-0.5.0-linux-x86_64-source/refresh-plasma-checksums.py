#!/usr/bin/env python3
"""Record a recipient's local protocol changes for Cargo directory-source use."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
crate = root / 'vendor/wayland-protocols-plasma-0.3.12'
checksums = crate / '.cargo-checksum.json'
before = json.loads(checksums.read_text())
files = {p.relative_to(crate).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(crate.rglob('*')) if p.is_file() and p.name != '.cargo-checksum.json'}
changed = [{'path': p, 'original_sha256': before['files'].get(p), 'modified_sha256': files.get(p)}
           for p in sorted(set(before['files']) | set(files)) if before['files'].get(p) != files.get(p)]
if not changed:
    print('No modified files; checksums unchanged.')
else:
    checksums.write_text(json.dumps({'package': before['package'], 'files': files}, sort_keys=True) + '\n')
    record = root / 'plasma-modifications.json'
    history = json.loads(record.read_text()) if record.exists() else []
    history.append(changed)
    record.write_text(json.dumps(history, indent=2, sort_keys=True) + '\n')
    print(f'Recorded {len(changed)} modified file(s).')
