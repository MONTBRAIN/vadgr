Vadgr 0.5.0 Linux AppImage runtime corresponding-source delivery

Scope
This bundle supplies source, exact patches, build recipes and notices for the
Type2 AppImage runtime, including the statically linked libfuse 3.15.0 library.
It is the source-based LGPL 2.1 section 6(a) route, not a URL-only written offer.
The Vadgr application inside the SquashFS is independent and has its own source
delivery. Do not mistake this runtime bundle for complete application source.

Runtime binding
Upstream AppImage/type2-runtime commit:
8f39b89e2ac31e1640b3d3f7e9a5108e6ce805fa
Original runtime-x86_64: 944632 bytes, SHA256
156f4bdbde9c52d01814600013e0a273f0118dc2de98975f3c8c63427ec79074
Matched debug companion SHA256:
3313d9de576c0772e1054877fd2f9566cd38d16c5e55ee3015005331c3754074
The GNU debuglink CRC was checked with a read-only ELF parser. No byte-identical
rebuild is claimed. Source provenance and observed linked scope are in evidence/.

Contents
archives/ retains original complete source archives with their licenses and
build scripts. The zstd release archive is retained for original-review context;
the distinct zstd-1.5.6-alpine.tar.gz archive is the SHA512-verified Alpine source
and is the one selected by the offline preparation helper. Full source archives
include tools/tests/platform alternatives under their own terms; binary-only
license conclusions do not relicense those source files.
alpine-recipes/ retains exact musl1.2.5-r11, mimalloc2.1.7-r0, zstd1.5.6-r2 and
zlib1.3.2-r0 recipes and all referenced patches/auxiliary sources.
GCC CRT source/grants and its 39 verified distro patches are retained in legal/.
GCC/clang, binutils, Meson, CMake, autotools, Ninja and standard Linux headers are
build tools/platform inputs, not bundled runtime programs. Provide a compatible
builder; this bundle neither installs nor replaces host tools.

Offline preparation (Python >=3.12 and patch required)
  python3 relink.py verify
  python3 relink.py prepare --work /your/dedicated/new/runtime-work
The work path must be new and contain no whitespace. It is not deleted on error.
All archives are checked, safely extracted, and all 12 applicable patches are
applied: 10 musl and the upstream libfuse mount.c patch with zero fuzz; the exact
Alpine mimalloc patch uses its normal fuzz2 allowance because old MI_VALGRIND
context changed in2.1.7. preparation.json retains every patch output. Two build metadata files are
generated explicitly: musl/VERSION=1.2.5 and the upstream runtime version URL.

Modify the prepared library source, for example sources/libfuse/, then build.
Keep the original archives and a record of your modifications. The provided
mount.c patch is an upstream AppImage modification to libfuse; it is not original
unmodified libfuse. Its exact patch is retained in the Type2 runtime source.

Builder and full relink
Use an already provisioned, disposable x86_64 Alpine3.21 environment. Do not run
upstream chroot scripts on a general-purpose host. Original observed compiler
packages are GCC14.2.0-r4 and clang19.1.4-r0, with musl-dev1.2.5-r11. Original
Dockerfile, dependency installer, Makefile and distribution APKBUILD recipes
remain in the bundle, together with the original upstream build log. These are
the authoritative original flags (including the original zstd PGO/LTO recipe).

Prerequisites: gcc, g++, clang, binutils/ar, make, Python3, patch, pkg-config,
Meson, Ninja, CMake, autoconf, automake, libtool, and standard Linux development
headers. The build action does not download anything or install host packages.
It builds in runtime-work only, one compilation job at a time.
  python3 relink.py plan --work /your/dedicated/new/runtime-work
  python3 relink.py build --work /your/dedicated/new/runtime-work

The convenience driver rebuilds musl, zlib, zstd, secure mimalloc, modified
libfuse and squashfuse into a local prefix. Its final static-PIE link explicitly
uses rebuilt musl startup/libc and the builder's GCC CRT/libgcc. It records the
complete final link command and keeps all build inputs/object files. It disables
unneeded libfuse tools/tests/examples and uses simple source builds instead of
Alpine's zstd PGO/LTO optimization. These deliberate differences support recipient
modification/relinking; they are not a claim to reproduce the release byte-for-byte.
Review qualification.json: the full driver was NOT executed in this preparation
environment. Any build incompatibility must be fixed and recorded before claiming
a qualified full rebuild. The retained original scripts also allow manual builds.

Install a modified runtime into a NEW AppImage
  python3 replace_runtime.py Original.AppImage runtime-work/out/runtime-x86_64 Modified.AppImage --original-runtime-length 944632
Use --expected-appimage-sha256 with the distributor's final whole-AppImage hash
when available. The helper requires ELF/AI2 headers and SquashFS magic at the
specified original runtime boundary. If final packaging adds padding, supply its
documented actual SquashFS offset; do not guess. It preserves the complete original
SquashFS payload bytes and refuses to overwrite an existing output. The original
file is not changed. This procedure recreates no publisher signature; modified
copies must not be represented as signed/endorsed releases. If runtime size changes,
the SquashFS automatically moves after the new ELF. The runtime computes that offset.

Rights and delivery
Read LGPL-NOTICE.txt and legal/LICENSES/runtime-appimage-libfuse/. This source
delivery is intended to accompany the distributed runtime with sufficient source
to modify libfuse and relink. No independent proprietary object-only application
module is needed: the Type2 runtime and its static dependencies are supplied as
source. Source archives include their original notices and licensing.
The packaging integration must ship this actual archive (or the complete expanded
source bundle), its conspicuous LGPL notice, and the corresponding license texts.
Do not substitute a promise, future publication or this README's source URLs.
Do not apply package restrictions that prohibit these modification/debugging
rights. No publisher or whole-package approval is represented by this bundle.

Delivery helpers
relink.py and replace_runtime.py accompany Vadgr under its Apache2.0 LICENSE.
Their permissions do not replace the separate upstream source-file licenses.
