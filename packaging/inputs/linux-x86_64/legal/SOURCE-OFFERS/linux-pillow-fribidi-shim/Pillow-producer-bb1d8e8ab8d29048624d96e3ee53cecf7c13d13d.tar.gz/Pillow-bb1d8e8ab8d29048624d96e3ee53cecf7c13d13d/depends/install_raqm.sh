#!/usr/bin/env bash
# install raqm


archive=libraqm-0.10.5

./download-and-extract.sh $archive https://raw.githubusercontent.com/python-pillow/pillow-depends/main/$archive.tar.gz

pushd $archive

meson build --prefix=/usr && ninja -C build install

popd
