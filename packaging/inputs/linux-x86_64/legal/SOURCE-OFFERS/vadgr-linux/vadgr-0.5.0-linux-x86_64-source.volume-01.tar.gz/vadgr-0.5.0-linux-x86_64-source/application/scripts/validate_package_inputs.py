#!/usr/bin/env python3
"""Check approved package bytes. Approval identity comes from trusted source review,
not from a JSON boolean. This command never creates an approval record.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

import tomllib

if __package__:
    from scripts import rust_path_patches
else:
    import rust_path_patches

SOURCE_INPUTS = ("Cargo.lock", "packaging/cua/pins.toml", "packaging/cua/requirements.lock", "packaging/toolchain.json")
CLOSURE_MEANINGS = {
    "publisher": "The Publisher-owner approved the exact identity and public contacts.",
    "market_rights": "The Publisher-owner reviewed the named markets and accepted documented residual market risk; this is not worldwide legal certification.",
    "apache_compatibility": "The package terms preserve Apache-2.0 rights and carry the exact license and NOTICE.",
    "product_data": "The disclosures match the exact candidate's providers, network access, updates, telemetry, support, permissions and retained data.",
    "third_party_duties": "Every exact component has a resolved license conclusion and all required licenses, notices and source delivery.",
}
CLOSURES = tuple(CLOSURE_MEANINGS)
KINDS = {"cargo", "wheel", "runtime", "asset", "framework"}
REQUIRED_FILES = {
    "legal/TERMS.txt", "legal/LICENSE.txt", "legal/NOTICE.txt",
    "legal/PRIVACY-NOTICE.txt", "legal/SECURITY-AND-PERMISSIONS.txt",
    "legal/SUPPORT.txt", "legal/UNINSTALL-AND-DATA.txt", "README-OFFLINE.txt",
}
INVENTORY_KEYS = {"schema", "created", "version", "target", "terms_version", "terms_sha256", "source_inputs", "payload_manifest_sha256", "coverage", "components"}
REVIEW_KEYS = (INVENTORY_KEYS - {"coverage", "components", "created"}) | {"status", "synthetic", "inventory_sha256", "files", "closures"}
COMPONENT_KEYS = {"id", "name", "version", "kind", "sha256", "download_location", "copyright_text", "license_declared", "license_concluded", "license_files", "notice_required", "notice_files", "source_offer_required", "source_offer_files"}
TARGETS = {f"{arch}-{suffix}" for arch in ("aarch64", "x86_64") for suffix in ("apple-darwin", "unknown-linux-gnu", "pc-windows-msvc")}
# A new identifier needs an explicit supported-terms change, not a guessed license.
LICENSE_IDS = {"Apache-2.0", "MIT", "BSD-2-Clause", "BSD-3-Clause", "BSD-4-Clause", "ISC", "Zlib", "BSL-1.0", "CC0-1.0", "Unlicense", "MPL-2.0", "MS-RL", "OFL-1.1", "Ubuntu-font-1.0", "Bitstream-Vera", "Unicode-3.0", "Unicode-DFS-2016", "Unicode-DFS-2015", "Python-2.0", "PSF-2.0", "BlueOak-1.0.0", "0BSD", "BSD-3-Clause-Clear", "BSD-3-Clause-Open-MPI", "BSD-3-Clause-LBNL", "BSD-2-Clause-Views", "BSD-2-Clause-Patent", "BSD-3-Clause-Attribution", "MIT-0", "MIT-CMU", "MIT-open-group", "OpenSSL", "RHeCos-1.1", "Apache-1.1", "Artistic-2.0", "CC-BY-3.0", "CC-BY-4.0", "CC-BY-SA-4.0", "LGPL-2.1-only", "LGPL-2.1-or-later", "LGPL-3.0-only", "LGPL-3.0-or-later", "GPL-2.0-only", "GPL-2.0-or-later", "GPL-3.0-only", "GPL-3.0-or-later", "AGPL-3.0-only", "AGPL-3.0-or-later", "bzip2-1.0.6", "libpng-2.0", "Libpng", "FTL", "IJG", "TCL", "X11", "W3C", "HPND", "curl", "NCSA", "libtiff", "PostgreSQL", "CDLA-Permissive-2.0", "blessing"}
EXCEPTION_IDS = {"LLVM-exception", "GCC-exception-3.1", "Classpath-exception-2.0", "Autoconf-exception-3.0", "Bison-exception-2.2", "Bootloader-exception"}


def license_identifier(value):
    return isinstance(value, str) and (value in LICENSE_IDS or re.fullmatch(r"LicenseRef-[A-Za-z0-9.-]+-[a-f0-9]{64}", value) is not None)


class PackageInputError(Exception):
    """A fixed error category safe for build output."""


def require(condition: bool, category: str) -> None:
    if not condition:
        raise PackageInputError(category)


def canonical_json(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def canonical_text_sha256(value: bytes) -> str:
    canonical = value.replace(b"\r\n", b"\n")
    require(b"\r" not in canonical, "text line endings differ")
    return sha256_bytes(canonical)


def valid_hash(value: object) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def source_input_matches(name: str, data: bytes, expected: str) -> bool:
    if sha256_bytes(data) == expected:
        return True
    # Git stores these reviewed text inputs with LF. A native Windows checkout
    # can present the same committed text with CRLF. Accept only that exact,
    # reversible conversion. Never normalize a binary package input.
    text_suffixes = (".json", ".lock", ".toml")
    return (name == "Cargo.lock" or name.endswith(text_suffixes)) and b"\r\n" in data \
        and b"\r" not in data.replace(b"\r\n", b"") \
        and sha256_bytes(data.replace(b"\r\n", b"\n")) == expected


def release_source_inputs(target: str) -> set[str]:
    require(target in TARGETS, "invalid target")
    return (set(SOURCE_INPUTS) - {"packaging/cua/requirements.lock"}) | {
        f"packaging/cua/locks/{target}.lock", "packaging/cua/native-wheel-manifest.json"}


def profile_source_inputs(profile: str) -> set[str]:
    require(re.fullmatch(r"(windows|macos|linux|wsl)-(x86_64|aarch64)", profile) is not None,
            "invalid release profile")
    names = (set(SOURCE_INPUTS) - {"packaging/cua/requirements.lock"}) | {
        f"packaging/cua/profile-locks/{profile}.lock", "packaging/cua/native-wheel-manifest.json",
        "packaging/cua/profile-inputs.json", "packaging/cua/cua-profile-catalog.json",
        "packaging/cua/cua-profile-catalog.sigstore.json"}
    # The embedded loader contains additional static libraries. Its identity
    # must not change without invalidating the native Linux legal review.
    if profile.startswith("linux-"):
        names.add("packaging/linux/runtime.json")
    return names


def profile_from_inputs(names, target):
    names = set(names)
    if rust_path_patches.REGISTRY in names:
        if not rust_path_patches.SOURCE_INPUTS <= names:
            return None
        names -= rust_path_patches.SOURCE_INPUTS
    for system in ("windows", "macos", "linux", "wsl"):
        suffix = {"windows": "pc-windows-msvc", "macos": "apple-darwin",
                  "linux": "unknown-linux-gnu", "wsl": "unknown-linux-gnu"}[system]
        for architecture in ("x86_64", "aarch64"):
            profile = system + "-" + architecture
            if target == architecture + "-" + suffix and names == profile_source_inputs(profile):
                return profile
    return None


def base_source_inputs(names):
    names = set(names)
    if rust_path_patches.REGISTRY in names and rust_path_patches.SOURCE_INPUTS <= names:
        names -= rust_path_patches.SOURCE_INPUTS
    return names


def relative_path(value: object) -> str:
    require(isinstance(value, str) and bool(value) and "\\" not in value and ":" not in value, "unsafe path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and str(path) == value and all(part not in {".", ".."} for part in path.parts), "unsafe path")
    require(all(ord(char) >= 32 and ord(char) != 127 for char in value), "unsafe path")
    reserved = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"} | {prefix + suffix for prefix in ("COM", "LPT") for suffix in "123456789¹²³"}
    require(not any(char in value for char in '<>"|?*'), "unsafe path")
    require(all(not part.endswith((".", " ")) and part.split(".", 1)[0].upper() not in reserved for part in path.parts), "unsafe path")
    return value


def read_owned(root: Path, relative: str) -> bytes:
    relative_path(relative)
    require(root.is_dir() and not root.is_symlink(), "unsafe path")
    for ancestor in (root.absolute(), *root.absolute().parents):
        require(not ancestor.is_symlink() and not getattr(ancestor, "is_junction", lambda: False)(), "unsafe path")
    path = root
    for part in PurePosixPath(relative).parts:
        path = path / part
        require(not path.is_symlink() and not getattr(path, "is_junction", lambda: False)(), "unsafe path")
    try:
        metadata = path.lstat()
        require(stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1, "unsafe file")
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0))
        with os.fdopen(descriptor, "rb") as source:
            opened = os.fstat(source.fileno())
            require(stat.S_ISREG(opened.st_mode) and opened.st_nlink == 1
                    and (metadata.st_dev, metadata.st_ino) == (opened.st_dev, opened.st_ino), "unsafe file")
            result = source.read()
            after = os.fstat(source.fileno())
            require((opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns, opened.st_nlink)
                    == (after.st_size, after.st_mtime_ns, after.st_ctime_ns, after.st_nlink), "changed input")
            return result
    except OSError:
        raise PackageInputError("missing input") from None


def parse_json(value: bytes) -> dict:
    def pairs(items):
        result = {}
        for key, item in items:
            require(key not in result, "invalid schema")
            result[key] = item
        return result
    try:
        result = json.loads(value, object_pairs_hook=pairs)
        require(isinstance(result, dict), "invalid schema")
        return result
    except (ValueError, UnicodeError):
        raise PackageInputError("invalid schema") from None


def validate_conclusion(value: object) -> None:
    require(isinstance(value, str) and 0 < len(value) <= 1024, "unresolved license")
    tokens = re.findall(r"[A-Za-z0-9.-]+|[()]", value)
    require("".join(tokens) == re.sub(r"\s", "", value), "unresolved license")
    position = 0

    def term():
        nonlocal position
        require(position < len(tokens), "unresolved license")
        if tokens[position] == "(":
            position += 1
            expression()
            require(position < len(tokens) and tokens[position] == ")", "unresolved license")
            position += 1
        else:
            require(license_identifier(tokens[position]), "unresolved license")
            position += 1
            if position < len(tokens) and tokens[position] == "WITH":
                position += 1
                require(position < len(tokens) and tokens[position] in EXCEPTION_IDS, "unresolved license")
                position += 1

    def expression():
        nonlocal position
        term()
        while position < len(tokens) and tokens[position] == "AND":
            position += 1
            term()

    expression()
    require(position == len(tokens), "unresolved license")


def validate_inventory(inventory: dict) -> None:
    require(isinstance(inventory, dict) and set(inventory) == INVENTORY_KEYS, "invalid inventory")
    require(type(inventory["schema"]) is int and inventory["schema"] == 1, "invalid inventory")
    require(isinstance(inventory["created"], str), "invalid inventory")
    try:
        created = datetime.strptime(inventory["created"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        require(created.strftime("%Y-%m-%dT%H:%M:%SZ") == inventory["created"], "invalid inventory")
    except ValueError:
        raise PackageInputError("invalid inventory") from None
    require(isinstance(inventory["version"], str) and re.fullmatch(r"\d+\.\d+\.\d+", inventory["version"]), "invalid inventory")
    require(isinstance(inventory["target"], str) and inventory["target"] in TARGETS, "invalid inventory")
    require(isinstance(inventory["terms_version"], str) and re.fullmatch(r"\d+(?:\.\d+)+", inventory["terms_version"]), "invalid inventory")
    require(valid_hash(inventory["terms_sha256"]) and valid_hash(inventory["payload_manifest_sha256"]), "invalid inventory")
    require(isinstance(inventory["source_inputs"], dict)
            and (base_source_inputs(inventory["source_inputs"]) in (set(SOURCE_INPUTS), release_source_inputs(inventory["target"]))
                 or profile_from_inputs(inventory["source_inputs"], inventory["target"]) is not None)
            and all(valid_hash(value) for value in inventory["source_inputs"].values()), "invalid inventory")
    coverage = inventory["coverage"]
    require(isinstance(coverage, dict) and set(coverage) == KINDS, "incomplete coverage")
    components = inventory["components"]
    require(isinstance(components, list) and bool(components), "incomplete coverage")
    identifiers = set()
    file_paths = {}
    for component in components:
        require(isinstance(component, dict) and set(component) == COMPONENT_KEYS, "invalid component")
        identifier = component["id"]
        require(isinstance(identifier, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", identifier)
                and identifier not in identifiers and identifier != "DOCUMENT", "invalid component")
        identifiers.add(identifier)
        require(isinstance(component["kind"], str) and component["kind"] in KINDS and valid_hash(component["sha256"]), "invalid component")
        for field in ("name", "version", "license_declared"):
            require(isinstance(component[field], str) and bool(component[field].strip())
                    and not any(ord(char) < 32 for char in component[field]), "invalid component")
        validate_conclusion(component["license_concluded"])
        # SPDX LicenseDeclared records upstream metadata.  It may honestly be
        # NOASSERTION even when review has concluded the actual grant from the
        # retained license bytes.  Do not turn missing metadata into a release
        # blocker or invent a declaration on the upstream author's behalf.
        if component["license_declared"] != "NOASSERTION":
            validate_conclusion(re.sub(r"\bOR\b", "AND", component["license_declared"]))
        location = component["download_location"]
        require(isinstance(location, str), "invalid component")
        parsed = urlsplit(location)
        require(parsed.scheme == "https" and parsed.hostname and "." in parsed.hostname
                and not parsed.username and not parsed.password and not parsed.query and not parsed.fragment,
                "unresolved provenance")
        copyright_text = component["copyright_text"]
        # SPDX permits NOASSERTION when copyright information cannot reasonably
        # be determined.  Redistribution authority comes from the resolved
        # license conclusion and its retained bytes, not from manufacturing a
        # copyright-absence claim by decoding unrelated upstream test fixtures.
        require(isinstance(copyright_text, str) and bool(copyright_text.strip()), "unresolved copyright")
        if copyright_text == "NONE":
            require(component["kind"] in {"cargo", "runtime"} and component["source_offer_required"] is True,
                    "copyright absence evidence required")
            absence = [entry for entry in component["source_offer_files"]
                       if entry.get("path", "").endswith("/copyright-absence.json")]
            archives = [entry for entry in component["source_offer_files"]
                        if (component["kind"] == "cargo" and entry.get("path", "").endswith(".crate")
                            and entry.get("sha256") == component["sha256"])
                        or (component["kind"] == "runtime" and entry.get("path", "").endswith("/observed-source.zip"))]
            require(len(absence) == len(archives) == 1, "copyright absence evidence required")
        covered_licenses = set()
        for field in ("notice_required", "source_offer_required"):
            require(type(component[field]) is bool, "invalid component")
        for field, prefix in (("license_files", "legal/LICENSES/"), ("notice_files", "legal/NOTICES/"), ("source_offer_files", "legal/SOURCE-OFFERS/")):
            files = component[field]
            require(isinstance(files, list), "incomplete coverage")
            if field == "license_files" or component[field.replace("_files", "_required")]:
                require(bool(files), "incomplete coverage")
            for entry in files:
                keys = {"path", "sha256", "license_ids"} if field == "license_files" else {"path", "sha256"}
                require(isinstance(entry, dict) and set(entry) == keys and valid_hash(entry["sha256"]), "invalid component")
                if field == "license_files":
                    ids = entry["license_ids"]
                    require(isinstance(ids, list) and bool(ids) and all(license_identifier(item) or item in EXCEPTION_IDS for item in ids)
                            and len(set(ids)) == len(ids), "incomplete license coverage")
                    require(all(not item.startswith("LicenseRef-") or item.endswith("-" + entry["sha256"]) for item in ids),
                            "custom license text identity differs")
                    covered_licenses.update(ids)
                name = relative_path(entry["path"])
                portable_name = unicodedata.normalize("NFC", name).casefold()
                require(name.startswith(prefix), "incomplete coverage")
                prior = file_paths.get(portable_name)
                # One exact retained source archive can satisfy several
                # components built from that same source revision.  Requiring
                # byte-for-byte duplicate archives creates size, review and
                # update risk without adding evidence.  Licenses and notices
                # remain component-specific so their attribution stays clear.
                if prior is not None:
                    require(field == "source_offer_files" and prior == (field, entry["sha256"]),
                            "incomplete coverage")
                else:
                    file_paths[portable_name] = (field, entry["sha256"])
        concluded_atoms = set(re.findall(r"[A-Za-z0-9.-]+", component["license_concluded"])) - {"AND", "WITH"}
        require(covered_licenses == concluded_atoms, "incomplete license coverage")
    for kind, entry in coverage.items():
        require(isinstance(entry, dict) and set(entry) == {"status", "component_ids"}
                and entry["status"] == "complete" and isinstance(entry["component_ids"], list), "incomplete coverage")
        expected = {component["id"] for component in components if component["kind"] == kind}
        require(all(isinstance(value, str) for value in entry["component_ids"])
                and len(entry["component_ids"]) == len(expected) and set(entry["component_ids"]) == expected, "incomplete coverage")
        if kind in {"cargo", "wheel", "runtime"}:
            require(bool(expected), "incomplete coverage")


def expected_legal_files(inventory: dict) -> set[str]:
    return REQUIRED_FILES | {entry["path"] for component in inventory["components"]
                             for field in ("license_files", "notice_files", "source_offer_files") for entry in component[field]}


def validate_copyright_absence(inventory, files):
    import tarfile
    if __package__:
        from scripts.copyright_absence import audit_archive, audit_source_tree_zip
    else:
        from copyright_absence import audit_archive, audit_source_tree_zip
    for component in inventory["components"]:
        if component["copyright_text"] != "NONE":
            continue
        records = component["source_offer_files"]
        archive = next(row for row in records if (row["path"].endswith(".crate") and row["sha256"] == component["sha256"])
                       or (component.get("kind") == "runtime" and row["path"].endswith("/observed-source.zip")))
        evidence = next(row for row in records if row["path"].endswith("/copyright-absence.json"))
        try:
            source = files[archive["path"]]
            require(sha256_bytes(source) == archive["sha256"], "copyright absence source differs")
            actual = (audit_source_tree_zip(source, component["sha256"]) if archive["path"].endswith(".zip")
                      else audit_archive(source, component["sha256"]))
        except (ValueError, OSError, tarfile.TarError, zipfile.BadZipFile) as error:
            raise PackageInputError("copyright absence source differs") from error
        require(actual["eligible_for_reviewed_NONE"] is True
                and canonical_json(actual) == files[evidence["path"]], "copyright absence evidence differs")


def render_rtf(text: str) -> bytes:
    result = [r"{\rtf1\ansi\deff0\uc1 "]
    for char in text:
        if char in "\\{}":
            result.append("\\" + char)
        elif char == "\n":
            result.append("\\par\n")
        elif char == "\r":
            result.append("\\u13?")
        elif char == "\t":
            result.append("\\tab ")
        elif 32 <= ord(char) < 127:
            result.append(char)
        else:
            encoded = char.encode("utf-16-le")
            for offset in range(0, len(encoded), 2):
                unit = int.from_bytes(encoded[offset:offset + 2], "little", signed=True)
                result.append(f"\\u{unit}?")
    return ("".join(result) + "}\n").encode("ascii")


def extracted_license_info(inventory, files):
    extracted = {}
    for component in inventory["components"]:
        for entry in component["license_files"]:
            for identifier in entry["license_ids"]:
                if not identifier.startswith("LicenseRef-"):
                    continue
                require(files is not None and entry["path"] in files, "custom license text required")
                raw = files[entry["path"]]
                require(identifier.endswith("-" + sha256_bytes(raw)), "custom license text identity differs")
                extracted[identifier] = {"licenseId": identifier, "extractedText": raw.decode("utf-8"),
                    "comment": "Exact retained terms; this identifier is not an approval or a claim of SPDX-list equivalence."}
    return [extracted[key] for key in sorted(extracted)]


def build_sbom(inventory: dict, files=None) -> dict:
    packages = [{"SPDXID": "SPDXRef-" + item["id"], "name": item["name"], "versionInfo": item["version"],
                 "downloadLocation": item["download_location"], "filesAnalyzed": False,
                 "checksums": [{"algorithm": "SHA256", "checksumValue": item["sha256"]}],
                 "licenseConcluded": item["license_concluded"], "licenseDeclared": item["license_declared"],
                 "copyrightText": item["copyright_text"]} for item in sorted(inventory["components"], key=lambda item: item["id"])]
    result = {"spdxVersion": "SPDX-2.3", "dataLicense": "CC0-1.0", "SPDXID": "SPDXRef-DOCUMENT",
            "name": "vadgr-" + inventory["version"] + "-" + inventory["target"],
            "documentNamespace": "https://spdx.org/spdxdocs/vadgr-" + sha256_bytes(canonical_json(inventory)),
            "creationInfo": {"created": inventory["created"], "creators": ["Tool: vadgr-package-inputs"]},
            "packages": packages, "relationships": [{"spdxElementId": "SPDXRef-DOCUMENT", "relationshipType": "DESCRIBES",
                                                      "relatedSpdxElement": item["SPDXID"]} for item in packages]}
    extracted = extracted_license_info(inventory, files)
    if extracted:
        result["hasExtractedLicensingInfos"] = extracted
    return result


def aggregate_files(inventory: dict, files: dict[str, bytes], field: str) -> bytes:
    result = []
    for component in sorted(inventory["components"], key=lambda item: item["id"]):
        for entry in sorted(component[field], key=lambda item: item["path"]):
            data = files[entry["path"]]
            if field == "source_offer_files" and entry["path"].lower().endswith(
                    (".zip", ".whl", ".crate", ".tar.gz", ".tar.xz", ".tgz")):
                data = (f"Included source archive: {entry['path']}\n"
                        f"SHA-256: {sha256_bytes(data)}\n").encode()
            result.extend([component["name"].encode("utf-8") + b"\n", data, b"\n"])
    return b"".join(result) or b"No additional third-party NOTICE files are required by the component inventory.\n"


def validate_package_inputs(root: Path, source_root: Path, version: str, target: str, *,
                            payload_manifest: Path | None = None, source_only: bool = False) -> dict:
    try:
        return _validate_package_inputs(root, source_root, version, target, payload_manifest, source_only)
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError):
        raise PackageInputError("invalid package inputs") from None


def validate_patched_sources(source_root, inventory):
    """The lock alone cannot bind the bytes of selected path dependencies."""
    try:
        patches = rust_path_patches.load(source_root)
    except (ValueError, OSError, KeyError, TypeError) as error:
        raise PackageInputError("invalid patched Cargo source binding") from error
    inputs = inventory["source_inputs"]
    if not patches:
        require(rust_path_patches.REGISTRY not in inputs, "obsolete patch source inputs")
        return
    require(rust_path_patches.SOURCE_INPUTS <= set(inputs), "unbound patched Cargo source inputs")
    require(all(source_input_matches(name, read_owned(source_root, name), inputs[name])
                for name in rust_path_patches.SOURCE_INPUTS), "patched Cargo source inputs changed")
    components = {row["name"]: row for row in inventory["components"] if row["kind"] == "cargo"}
    profile = profile_from_inputs(inputs, inventory["target"])
    # WSL shares the Rust target triple but ships the headless build, not the
    # native Linux GUI. Only its exact profile input set selects this branch.
    if not inventory["target"].endswith("unknown-linux-gnu") or (profile and profile.startswith("wsl-")):
        require(not (set(patches) & set(components)), "Linux GUI patch component on another profile")
        return
    for name, patch in patches.items():
        item = components.get(name)
        require(item is not None and item["version"] == patch["version"]
                and item["sha256"] == patch["manifest_sha256"]
                and item["license_declared"] == "MIT OR Apache-2.0"
                and item["license_concluded"] == rust_path_patches.CONCLUSIONS[name],
                "patched Cargo inventory differs")
        try:
            # Trusted review checks the historical URL object. Builds also work
            # from source archives or shallow checkouts: bind current bytes here.
            rust_path_patches.location_commit(patch, item["download_location"])
        except (ValueError, OSError) as error:
            raise PackageInputError("patched Cargo provenance differs") from error


def _validate_package_inputs(root, source_root, version, target, payload_manifest, source_only):
    require(type(source_only) is bool and target in TARGETS, "invalid target")
    require(not (source_only and payload_manifest is not None), "ambiguous validation scope")
    inventory_bytes = read_owned(root, "package-input-inventory.json")
    inventory = parse_json(inventory_bytes)
    validate_inventory(inventory)
    review = parse_json(read_owned(root, "package-input-review.json"))
    require(set(review) == REVIEW_KEYS and type(review["schema"]) is int and review["schema"] == 1, "invalid review")
    require(review["status"] == "approved" and review["synthetic"] is False, "approval required")
    require(isinstance(review["closures"], dict) and set(review["closures"]) == set(CLOSURES)
            and all(value is True for value in review["closures"].values()), "review incomplete")
    require(inventory["version"] == version and inventory["target"] == target, "identity mismatch")
    for field in REVIEW_KEYS & INVENTORY_KEYS:
        require(review[field] == inventory[field], "review identity mismatch")
    require(review["inventory_sha256"] == sha256_bytes(inventory_bytes), "inventory mismatch")
    source_bytes = {name: read_owned(source_root, name) for name in inventory["source_inputs"]}
    require(all(source_input_matches(name, data, inventory["source_inputs"][name])
                for name, data in source_bytes.items()), "source input mismatch")
    source_version = tomllib.loads(read_owned(source_root, "Cargo.toml").decode("utf-8"))["package"]["version"]
    require(source_version == version, "source version mismatch")
    validate_patched_sources(source_root, inventory)
    pins = tomllib.loads(source_bytes["packaging/cua/pins.toml"].decode("utf-8"))
    target_pins = pins["targets"][target]
    schema_two = base_source_inputs(source_bytes) == release_source_inputs(target)
    profile = profile_from_inputs(source_bytes, target)
    lock_name = (f"packaging/cua/profile-locks/{profile}.lock" if profile else
                 f"packaging/cua/locks/{target}.lock" if schema_two else "packaging/cua/requirements.lock")
    expected_payload = {"schema": 2 if schema_two else 1, "cua_version": pins["cua"], "python_version": pins["python"],
                        "python_build": pins["python_build"], "target": target,
                        "requirements_sha256": inventory["source_inputs"][lock_name],
                        "python_archive_sha256": target_pins["python_sha256"], "uv_archive_sha256": target_pins["uv_sha256"]}
    if profile:
        profile_inputs = parse_json(source_bytes["packaging/cua/profile-inputs.json"])
        catalog_bytes = source_bytes["packaging/cua/cua-profile-catalog.json"]
        catalog = parse_json(catalog_bytes)
        require(profile_inputs.get("schema") == 1 and profile_inputs.get("catalog_sha256") == sha256_bytes(catalog_bytes)
                and profile_inputs["profiles"][profile]["requirements_sha256"] == inventory["source_inputs"][lock_name],
                "profile legal input binding differs")
        expected_payload.update(schema=3, cua_version=catalog["cua_version"], release_profile=profile,
            cua_profile_manifest_sha256=profile_inputs["profiles"][profile]["role_manifest_sha256"])
    if not source_only:
        if payload_manifest is None:
            payload_bytes = read_owned(root, "lib/cua/payload.json")
        else:
            payload_bytes = read_owned(payload_manifest.parent, payload_manifest.name)
        require(sha256_bytes(payload_bytes) == inventory["payload_manifest_sha256"], "payload identity mismatch")
        actual_payload = parse_json(payload_bytes)
        if schema_two or profile:
            runtime_root = payload_manifest.parent if payload_manifest else root / "lib/cua"
            expected_payload.update({
                "wheel_manifest_sha256": inventory["source_inputs"]["packaging/cua/native-wheel-manifest.json"],
                "installed_inventory_sha256": sha256_bytes(read_owned(runtime_root, "installed-inventory.json")),
            })
        require(type(actual_payload.get("schema")) is int and actual_payload == expected_payload, "payload pins mismatch")
        if schema_two or profile:
            # This import is local because the runtime validator shares the safe readers here.
            if __package__:
                from scripts import cua_release_inputs
            else:
                import cua_release_inputs
            binding_keys = ["target", "requirements_sha256", "wheel_manifest_sha256"]
            if profile:
                binding_keys += ["release_profile", "cua_profile_manifest_sha256"]
            cua_release_inputs.validate_payload(runtime_root, {key: expected_payload[key] for key in binding_keys})
    generated = {"legal/TERMS.rtf", "legal/THIRD-PARTY-NOTICES.txt", f"sbom/vadgr-{version}.spdx.json"}
    if any(component["source_offer_files"] for component in inventory["components"]):
        generated.add("legal/SOURCE-OFFER.txt")
    expected_files = expected_legal_files(inventory) | generated
    hashes = review["files"]
    require(isinstance(hashes, dict) and set(hashes) == expected_files
            and all(valid_hash(value) for value in hashes.values()), "file inventory mismatch")
    actual_files = {"README-OFFLINE.txt"}
    for directory in ("legal", "sbom"):
        parent = root / directory
        require(parent.is_dir() and not parent.is_symlink(), "unsafe path")
        for path in parent.rglob("*"):
            require(not path.is_symlink() and not getattr(path, "is_junction", lambda: False)(), "unsafe path")
            if not path.is_dir():
                actual_files.add(path.relative_to(root).as_posix())
    require(actual_files == expected_files, "file inventory mismatch")
    files = {name: read_owned(root, name) for name in expected_files}
    validate_copyright_absence(inventory, files)
    require(all(sha256_bytes(data) == hashes[name] for name, data in files.items()), "file hash mismatch")
    for name in REQUIRED_FILES:
        text = files[name].decode("utf-8")
        require(bool(text.strip()) and "\x00" not in text, "invalid disclosure")
    require(sha256_bytes(files["legal/TERMS.txt"]) == inventory["terms_sha256"], "terms mismatch")
    require(files["legal/TERMS.rtf"] == render_rtf(files["legal/TERMS.txt"].decode("utf-8")), "terms rendering mismatch")
    for component in inventory["components"]:
        for field in ("license_files", "notice_files", "source_offer_files"):
            for entry in component[field]:
                require(bool(files[entry["path"]].strip()) and sha256_bytes(files[entry["path"]]) == entry["sha256"], "component text mismatch")
    require(files["legal/THIRD-PARTY-NOTICES.txt"] == aggregate_files(inventory, files, "notice_files"), "notice mismatch")
    if "legal/SOURCE-OFFER.txt" in generated:
        require(files["legal/SOURCE-OFFER.txt"] == aggregate_files(inventory, files, "source_offer_files"), "source offer mismatch")
    require(files[f"sbom/vadgr-{version}.spdx.json"] == canonical_json(build_sbom(inventory, files)), "SBOM mismatch")
    return {"schema": 1, "status": "approved", "scope": "source-inputs" if source_only else "assembled-payload",
            "version": version, "target": target, "terms_version": inventory["terms_version"],
            "terms_sha256": inventory["terms_sha256"], "payload_manifest_sha256": inventory["payload_manifest_sha256"],
            "inventory_sha256": review["inventory_sha256"], "component_count": len(inventory["components"]),
            "file_count": len(files)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--version", required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("--payload-manifest", type=Path)
    parser.add_argument("--source-only", action="store_true")
    args = parser.parse_args()
    try:
        result = validate_package_inputs(args.root, args.source_root, args.version, args.target,
                                         payload_manifest=args.payload_manifest, source_only=args.source_only)
        require(result.get("scope") == ("source-inputs" if args.source_only else "assembled-payload"), "validation scope mismatch")
        print(json.dumps(result, sort_keys=True))
        return 0
    except (PackageInputError, OSError, ValueError, TypeError, KeyError, UnicodeError):
        print("Package inputs failed validation.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
