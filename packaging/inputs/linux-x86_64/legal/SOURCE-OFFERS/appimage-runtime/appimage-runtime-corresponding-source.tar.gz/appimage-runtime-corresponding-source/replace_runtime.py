#!/usr/bin/env python3
"""Create a new modified AppImage without executing or overwriting either input."""
import argparse
import hashlib
from pathlib import Path

def replace(original,runtime,output,offset,expected=None):
    raw=original.read_bytes();new=runtime.read_bytes()
    if expected and hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Original AppImage digest differs')
    for data in (raw,new):
        if data[:4]!=b'\x7fELF' or data[8:11]!=b'AI\x02':raise ValueError('Expected Type2 AppImage runtime header')
    if raw[offset:offset+4]!=b'hsqs':raise ValueError('Expected SquashFS at supplied original runtime length; inspect final package layout')
    if len(new)<64:raise ValueError('Truncated new runtime')
    with output.open('xb') as f:f.write(new);f.write(raw[offset:])
    output.chmod(0o755)
    return {'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'new_runtime_length':len(new),
        'payload_sha256':hashlib.sha256(raw[offset:]).hexdigest()}
def main():
    p=argparse.ArgumentParser()
    p.add_argument('original',type=Path);p.add_argument('runtime',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--original-runtime-length',type=int,default=944632)
    p.add_argument('--expected-appimage-sha256')
    a=p.parse_args()
    print(replace(a.original,a.runtime,a.output,a.original_runtime_length,a.expected_appimage_sha256))
if __name__=='__main__':main()
