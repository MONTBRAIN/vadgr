use std::path::PathBuf;

fn repo_file(relative: &str) -> String {
    let path = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(relative);
    std::fs::read_to_string(path).unwrap()
}

#[test]
fn windows_package_is_per_user_and_owns_native_launch_entries() {
    let package = repo_file("packaging/windows/Package.wxs");
    assert!(package.contains("Scope=\"perUser\""));
    assert!(!package.contains("perUserOrMachine"));
    assert!(package.contains("Id=\"LocalAppDataFolder\""));
    assert!(package.contains("Name=\"Programs\""));
    assert!(package.contains("Target=\"[INSTALLFOLDER]vadgr-app.exe\""));
    assert!(package.contains("Software\\Microsoft\\Windows\\CurrentVersion\\Run"));
    assert!(package.contains("--daemon"));
    assert!(!package.contains("ProgramFilesFolder"));
    assert!(!package.contains("ServiceInstall"));
    let bundle = repo_file("packaging/windows/Bundle.wxs");
    assert!(!bundle.contains("WixStdBAScope"));
    let project = repo_file("packaging/windows/VadgrBundle.wixproj");
    assert!(project.contains("<OutputType>Bundle</OutputType>"));
    let msi_project = repo_file("packaging/windows/VadgrMsi.wixproj");
    assert!(msi_project.contains("$(GeneratedPayloadWxs)"));
    for group in ["Legal", "Sbom"] {
        assert!(msi_project.contains(&format!("$(Generated{group}Wxs)")));
        let developer = repo_file("packaging/windows/build.ps1");
        assert!(developer.contains(&format!("-p:Generated{group}Wxs=$generated{group}")));
        let trusted = repo_file("scripts/candidate/package-windows.ps1");
        assert!(trusted.contains(&format!("-p:Generated{group}Wxs=$generated{group}")));
    }
    assert!(!msi_project.contains("WixToolset.Heat"));
    let generator = repo_file("scripts/generate_windows_payload_wxs.py");
    assert!(generator.contains("uuid.uuid5"));
    assert!(generator.contains("payload contains a link"));
}

#[test]
fn burn_owns_terms_progress_repair_uninstall_and_console_launch() {
    let bundle = repo_file("packaging/windows/Bundle.wxs");
    assert!(bundle.contains("WixStandardBootstrapperApplication"));
    assert!(bundle.contains("Theme=\"rtfLargeLicense\""));
    assert!(bundle.contains("ThemeFile=\"$(var.ThemeFile)\""));
    assert!(bundle.contains("LocalizationFile=\"$(var.ThemeLocalizationFile)\""));
    assert!(bundle.contains("bal:BAFunctions=\"yes\""));
    assert!(bundle.contains("SourceFile=\"$(var.BAFunctionsPath)\""));
    assert!(bundle.contains("LicenseFile=\"$(var.TermsRtf)\""));
    assert!(bundle.contains("SuppressRepair=\"no\""));
    assert!(bundle.contains("LaunchTarget=\"[InstallFolder]\\vadgr-app.exe\""));
    assert!(bundle.contains("Name=\"TERMSACCEPTED\" Value=\"1\""));
    assert!(bundle.contains("WixBundleInstalled OR WixBundleUILevel = 4"));
    assert!(bundle.contains("Name=\"BUNDLESOURCE\""));
    assert!(bundle.contains("Name=\"PurgeOwnerData\""));
    assert!(bundle.contains("bal:Overridable=\"yes\""));
    assert!(bundle.contains("Name=\"PURGEOWNERDATA\" Value=\"[PurgeOwnerData]\""));
    assert!(bundle.contains("<MsiPackage"));
    let package = repo_file("packaging/windows/Package.wxs");
    assert!(package.contains("Condition=\"Installed OR TERMSACCEPTED = 1\""));
    assert!(package.contains("Id=\"RecordTermsAcceptance\""));
    assert!(package.contains("Id=\"CacheInstallVehicle\""));
    assert!(package.contains("__cache-install-vehicle"));
    assert!(package.contains("$(var.DevelopmentUnsigned) = false"));
    // The development admission installs under the same condition that drops
    // the Authenticode vehicle cache, so a release package can never carry one.
    assert!(package.contains("$(var.DevelopmentUnsigned) = true"));
    assert!(package.contains("Id=\"DevelopmentReceiptFile\""));
    assert!(package.contains("development-receipt.json"));
    assert!(package.contains("Execute=\"commit\""));
    assert!(package.contains("HideTarget=\"yes\""));
    assert!(package.contains("AllowDowngrades=\"yes\""));
    assert!(package.contains("util:RemoveFolderEx"));
    let receipt = repo_file("packaging/windows/install-receipt.json");
    assert!(receipt.contains("cache/previous-setup.exe"));
    let localization = repo_file("packaging/windows/VadgrTheme.wxl");
    assert!(localization.contains("Culture=\"en-US\""));
    assert!(localization.contains("Id=\"ConfirmCancelMessage\""));
    assert!(localization.contains("Id=\"FilesInUseTitle\""));
    let build = repo_file("packaging/windows/build.ps1");
    assert!(build.contains("[switch] $DevelopmentUnsigned"));
    assert!(build.contains("-p:DevelopmentUnsigned="));
    assert!(build.contains("windows_development_receipt.py"));
    // The bootstrapper is read back from the directory this build wrote it to.
    // Deriving that path from the project root instead let a build that set
    // CARGO_TARGET_DIR embed a months old DLL with no error anywhere.
    assert!(build.contains("--target-dir $baTargetDirectory"));
    assert!(build.contains("$baFunctionsPath = Join-Path $baTargetDirectory"));
    assert!(build.contains("was not built by this run"));
    assert!(!build.contains("Join-Path $projectRoot \"ba-functions\target"));
    assert!(build.contains("$SourceCommit -notmatch"));
    assert!(build.contains("A release package must not carry a development receipt."));
    assert!(build.contains("VADGR_TERMS_SHA256"));
    assert!(build.contains("-p:BAFunctionsPath="));
    assert!(build.contains("cargo rustc --locked"));
    assert!(build.contains("target-feature=+crt-static"));
    let project = repo_file("packaging/windows/VadgrMsi.wixproj");
    assert!(project.contains("<DevelopmentUnsigned Condition="));
    assert!(project.contains("DevelopmentUnsigned=$(DevelopmentUnsigned)"));
    assert!(project.contains("WixToolset.Util.wixext"));
    let theme = repo_file("packaging/windows/VadgrTheme.xml");
    // The reason for a refused install needs a control it can be written to.
    assert!(theme.contains("Name=\"TermsSubtitle\""));
    let ba = repo_file("packaging/windows/ba-functions/src/lib.rs");
    assert!(ba.contains("enum Acceptance"));
    assert!(ba.contains("VersionConflict"));
    assert!(ba.contains("fn conflict_message"));
    assert!(ba.contains("BAFunctionsCreate"));
    assert!(ba.contains("BA_FUNCTIONS_MESSAGE_ON_THEME_CONTROL_LOADED"));
    assert!(ba.contains("Terms version {} was accepted previously"));
    assert!(ba.contains("env!(\"VADGR_TERMS_SHA256\")"));
    assert!(ba.contains("eq_ignore_ascii_case(terms_sha256)"));
}

#[test]
fn custom_setup_theme_covers_every_terminal_installer_state() {
    let theme = repo_file("packaging/windows/VadgrTheme.xml");
    for page in [
        "Loading", "Help", "Install", "Progress", "Modify", "Success", "Failure",
    ] {
        assert!(
            theme.contains(&format!("<Page Name=\"{page}\">")),
            "missing installer page: {page}"
        );
    }
    for control in [
        "EulaRichedit",
        "EulaAcceptCheckbox",
        "InstallButton",
        "OverallCalculatedProgressbar",
        "RepairButton",
        "UninstallButton",
        "LaunchButton",
        "FailureMessageText",
    ] {
        assert!(
            theme.contains(&format!("Name=\"{control}\"")),
            "missing installer control: {control}"
        );
    }
    assert!(
        theme.contains(
            "If Vadgr was already installed, that working installation remains available."
        )
    );
}

#[test]
fn candidate_build_refuses_an_incomplete_payload() {
    let build = repo_file("packaging/windows/build.ps1");
    for required in [
        "vadgr.exe",
        "vadgr-app.exe",
        "legal\\TERMS.txt",
        "legal\\THIRD-PARTY-NOTICES.txt",
        "README-OFFLINE.txt",
        "spdx.json",
    ] {
        assert!(
            build.contains(required),
            "missing required input: {required}"
        );
    }
    assert!(build.contains("StartsWith('{\\rtf')"));
    assert!(!build.contains("signtool"));
    assert!(
        !build
            .lines()
            .any(|line| line.trim() == "'release-manifest.json',"),
        "the manifest hashes the final setup and therefore cannot be embedded in that setup"
    );
}
