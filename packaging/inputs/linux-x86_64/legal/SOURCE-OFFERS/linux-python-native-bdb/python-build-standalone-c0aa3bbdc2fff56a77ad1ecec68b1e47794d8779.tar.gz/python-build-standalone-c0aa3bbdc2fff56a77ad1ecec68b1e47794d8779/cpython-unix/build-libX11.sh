#!/usr/bin/env bash
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

set -ex

ROOT=$(pwd)

export PATH=/tools/${TOOLCHAIN}/bin:/tools/host/bin:$PATH
export PKG_CONFIG_PATH=/tools/deps/share/pkgconfig:/tools/deps/lib/pkgconfig

tar -xf "libX11-${LIBX11_VERSION}.tar.gz"
pushd "libX11-${LIBX11_VERSION}"

if [ "${CC}" = "musl-clang" ]; then
    EXTRA_FLAGS="--disable-shared"
fi

# configure doesn't support cross-compiling in malloc(0) returns null test.
# So we have to force a value.
if [ -n "${CROSS_COMPILING}" ]; then
  case "${TARGET_TRIPLE}" in
    aarch64-unknown-linux-gnu)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    armv7-unknown-linux-gnueabi)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    armv7-unknown-linux-gnueabihf)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    loongarch64-unknown-linux-gnu)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    mips-unknown-linux-gnu)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    mipsel-unknown-linux-gnu)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    mips64el-unknown-linux-gnuabi64)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    ppc64le-unknown-linux-gnu)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    riscv64-unknown-linux-gnu)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    s390x-unknown-linux-gnu)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    x86_64-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    aarch64-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    loongarch64-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    mips-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    mipsel-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    ppc64le-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    riscv64-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    s390x-unknown-linux-musl)
      EXTRA_FLAGS="${EXTRA_FLAGS} --enable-malloc0returnsnull"
      ;;
    *)
      echo "cross-compiling but malloc(0) override not set; failures possible"
      ;;
  esac
fi

# Avoid dlopen("libXcursor.so.1") from the OS, which can go horribly wrong. We
# might not need to avoid this if we switch to shipping X11 as shared
# libraries, and ideally if we ship libXcursor ourselves.
EXTRA_FLAGS="${EXTRA_FLAGS} --disable-loadable-xcursor"

# CC_FOR_BUILD is here because configure doesn't look for `clang` when
# cross-compiling. So we force it.
# RAWCPP is X.Org's stdin-fed preprocessor command. Use the full path to
# the target compiler driver with "-" to read from stdin.
CFLAGS="${EXTRA_TARGET_CFLAGS} -fPIC -I/tools/deps/include" \
  CPPFLAGS="${EXTRA_TARGET_CFLAGS} -fPIC -I/tools/deps/include" \
  LDFLAGS="${EXTRA_TARGET_LDFLAGS}" \
  CC_FOR_BUILD="${HOST_CC}" \
  CFLAGS_FOR_BUILD="-I/tools/deps/include" \
  CPPFLAGS_FOR_BUILD="-I/tools/deps/include" \
  RAWCPP="$(command -v "${CC}") -E -"\
  ./configure \
    --build="${BUILD_TRIPLE}" \
    --host="${TARGET_TRIPLE}" \
    --prefix=/tools/deps \
    --disable-silent-rules \
    ${EXTRA_FLAGS}

make -j "$(nproc)"
make -j "$(nproc)" install DESTDIR="${ROOT}/out"
