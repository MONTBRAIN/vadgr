Vadgr Linux x86_64 corresponding source snapshot

source-identity.json names the committed code snapshot. application-files.json
records all retained application/build files and modes; SHA256SUMS covers the
complete delivered file set. This archive does not embed its containing commit,
final executable hash or final development-receipt hash.

Extract all independent volumes into one directory and verify the volume
checksums and then SHA256SUMS. Do not concatenate the volume archives.
Supply the adjacent final AppImage .development.json receipt when rebuilding:

  ./rebuild.sh --receipt /path/to/Vadgr-0.5.0-linux-x86_64-installer.development.json

The helper checks canonical unsigned Linux x86_64 receipt metadata and validates
the complete retained application-file manifest. It uses the receipt's exact
source_commit and source_tree as compile configuration. It does not infer them
from a newer branch or claim an unsigned receipt authenticates a publisher.
An independent final-package check must compare the retained source snapshot
with the final producer Git tree and bind these volumes through that receipt's
AppDir inventory. A prior receipt may be used for explicitly labeled source-only
qualification; that result is not final-package correspondence.

Install native Ubuntu 24.04 x86_64 build prerequisites before going offline:
Rust 1.97.1 and x86_64-unknown-linux-gnu target, C/C++ tools, pkg-config, binutils,
libxkbcommon-dev, libwayland-dev, libudev-dev, libdbus-1-dev and libssl-dev.
The helper selects the offline locked release recipe, two Cargo jobs, exact
Linux profile and linux-unsigned-qualification feature (which includes native-gui).
It rejects neither changed binary output nor host differences as byte reproduction
is not promised. Build.rs refuses WSL, nonnative targets and release-verifier.
Output is application/target/x86_64-unknown-linux-gnu/release/vadgr.
The native runtime policy checker is application/scripts/check_linux_build_policy.py.

The 557 original crate archives retain their source, licenses, notices, examples
and tests as upstream provenance. Two selected same-version crates are patched
under application/vendor: accesskit_atspi_common 0.18.1 and accesskit_unix 0.21.1.
Cargo.lock selects those local paths. packaging/rust-patches.json and its complete
file manifests bind every patched source file; each PATCHES.md records changes.
The original registry vendor sources include directory checksums. The 158
resolution-only entries contain exact upstream manifests
and locally written Apache-2.0 fail-closed stubs, not other-platform SDK source.
Their package checksum preserves original archive identity; their files checksums
describe only delivered files. They are not substitutes for compiled dependencies.
No other platform or alternative feature combination is supported by this packet.
SOURCE-GRANT-REVIEW.txt and source-grant-review.json preserve the grant inventory;
application/LICENSE and legal/ retain license and notice materials.

For Plasma modifications, copy this bundle, edit the protocol XML beneath
vendor/wayland-protocols-plasma-0.3.12/plasma-wayland-protocols/src/protocols/,
run python3 refresh-plasma-checksums.py, and rebuild. Preserve original archives
and manifests as provenance; plasma-modifications.json describes the derivative.
Use a clean target when testing scanner consumption. The original whole-bundle
SHA256SUMS intentionally ceases to match modified files. Source identity then
describes the original baseline, not an assertion that your modified output
matches an original receipt. For application-source changes, update a separately
identified derivative application manifest as well and describe modifications
and dates when redistributing under the applicable licenses.

SOURCE-QUALIFICATION.json records only measured source-build results for this
edition. Ubuntu 26.04 source qualification is not Ubuntu 24.04 byte reproduction,
application E2E, package approval, publisher authentication or legal approval.
The executable recipe does not reconstruct the Python CUA payload, AppImage
runtime, complete installer vehicle, signatures or production attestations.
Their independently distributed materials remain separate source-delivery duties.
Git state, credentials, agent policy, E2E records and unrelated platform packaging
are omitted; required executable inputs are retained. Keep all volumes together.
Retain applicable source access, grants and notices when distributing the binary.
